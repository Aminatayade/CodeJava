package MesClasses;

public class Cercle implements ICercle {
private  float rayon;
public  Cercle () {}
public  Cercle ( float rayon ) {this.rayon=rayon;}
	@Override
	public float getrayon() {
		// TODO Auto-generated method stub
		return rayon;
	}

	@Override
	public void setRayon(float rayon) {
		// TODO Auto-generated method stub
		this.rayon=rayon;
	}

	@Override
	public float perimetre() {
		// TODO Auto-generated method stub
		return  2*ICercle.pi*rayon;
	}

	@Override
	public  double surface() {
		// TODO Auto-generated method stub
		return ICercle.pi*Math.pow(rayon, 2);
	}

}
