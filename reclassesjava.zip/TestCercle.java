package MesClasses;

public class TestCercle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Cercle c= new  Cercle ();
  c.setRayon(5);
  System.out.println ("Le p�rim�tre du cercle est : "+ c.perimetre() +" m�tres");
  System.out.println ("La surface du cercle est : "+ c.surface()+" m�");
	}

}
