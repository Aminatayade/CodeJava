package MesClasses;

import java.sql.Date;
import java.util.Scanner;

public class TestEleve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner in= new Scanner (System.in);
		Eleve e=new  Eleve();
		e.setNom("SALL");
		e.setPrenom("Pape Moussa");
		String  sexe;
		do {
			System.out.print("Saisir le sexe  (M ou F) :" );
			sexe=in.next();
		}   while (! (sexe.equals("M") || sexe.equals("F")) );
		e.setSexe (EnumSexe.valueOf(sexe));
			
		String  datenaiss;
		System.out.print("Saisir la  date de naissance sous format AAAA-MM-JJ :" );
		datenaiss=in.next(); 
		e.setDatenaiss(Date.valueOf(datenaiss));
		
		/*
		 * String [] parents= {"Mamadou SALL", "Fatou BA"}; e.setParents(parents);
		 */
		String [] vparents = new String [2];
		System.out.print("Saisir le pr�nom et nom du p�re :" );
		in.nextLine(); //retour chario dans Scanner
		 vparents[0]=in.nextLine();
		 System.out.print("Saisir le pr�nom et nom de la m�re:" );
		 vparents[1]=in.nextLine();
			e.setParents(vparents);
			/*
			 * int jour=2, mois=2, ann�e=1980, heure=15, minute =25, seconde=30;
			 * java.util.Date heurenaiss = null;
			 * 
			 * heurenaiss.setDate(jour); heurenaiss.setMonth(mois);
			 * heurenaiss.setYear(ann�e); heurenaiss.setHours(heure);
			 * heurenaiss.setMinutes(minute); heurenaiss.setSeconds(seconde); ;
			 * e.seHeurenaiss(heurenaiss);
			 */
			//affichafe de l'�l�ve
			System.out.println ("Le Pr�nom est :"+e.getPrenom());
			System.out.println ("Le nom est :"+e.getNom());
			System.out.println ("Le sexe est :"+e.getSexe());
			System.out.println ("La date de naissance est :"+e.getDatenaiss());
			//System.out.println ("L'heure de naisance est :"+e.getheurenaiss());
		String []  mesparents=e.getParents();
		for (int i=0; i<mesparents.length; i++)
			System.out.println ("Parent : "+ (i+1) +" "+mesparents[i]);


	}

}
