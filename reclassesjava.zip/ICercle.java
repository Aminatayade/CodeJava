package MesClasses;

public interface ICercle {
 float pi =3.14f;
 public float getrayon();
 public   void setRayon (float rayon);
 public    float perimetre ();
 public   double surface ();
 
}
