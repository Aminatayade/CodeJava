package MesClasses;

import java.util.Scanner;

public class TestVecteurImplicite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int T1 [] ={4,5,2,1};
		Scanner in=new Scanner (System.in);
		int n;
		do
		{
		   System.out.print("Donner la taille du tableau (n positif) :");
			n=in.nextInt();
		} while(n<=0);
		int T1 []= new int[n];   //d�claration et allocation 
		for  (int i=0; i<T1.length; i++)
		{
			System.out.print("Saisir l'�l�ment du tableau � la position: "+i+" ");
			T1[i]=in.nextInt();
			///affichage pas de sens
		}
		
		System.out.println ("Affichage verticale");
		for (int i=0; i<T1.length;i++)
		System.out.println(T1[i]);
		
		System.out.println ("Affichage  horizontale");
		for (int i=0; i<T1.length;i++)
		System.out.print(T1[i]+"\t");
		

	}

}
