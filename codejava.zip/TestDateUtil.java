package MesClasses;
import java.util.Date;
import java.util.Scanner;

public class TestDateUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 2020-01-04
		
			  Date d = new Date();
	System.out.println( "Jour :"+d.getDay() +" Mois: "+(d.getMonth()+1)+
	" Ann�e: "+(d.getYear()+1900)+ " Heure: "+d.getHours()+ " Minutes "+
			d.getMinutes()+ "  Seondes: "+d.getSeconds());
			 
		
              
	}

}
