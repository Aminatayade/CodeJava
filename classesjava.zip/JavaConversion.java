package MesClasses;

public class JavaConversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a=120, b=1 ;   byte  s= (byte) (a+b) ;
System.out.println(s);
	}

}
