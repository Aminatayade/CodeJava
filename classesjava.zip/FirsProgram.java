package MesClasses;

public class FirsProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="3.14";
		float pi=Float.parseFloat(s);
	 double  pi2= Double.parseDouble(s);
	 //int i=Integer.parseInt(s);
System.out.println(pi +" \t"+ pi2);

String s1=String.valueOf (true);
System.out.println("S1= "+ s1);

//System.out.println(args[0] +"\t"+args[1] );
	}

}
