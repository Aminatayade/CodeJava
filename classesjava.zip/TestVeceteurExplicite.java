package MesClasses;

public class TestVeceteurExplicite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//intialisation statique (explicite)
		int T1 [] ={4,5,2,1};
		System.out.println ("Affichage verticale");
		for (int i=0; i<T1.length;i++)
		System.out.println(T1[i]);
		
		System.out.println ("Affichage  horizontale");
		for (int i=0; i<T1.length;i++)
		System.out.print(T1[i]+"\t");
///programme qui trie le tableau
	}

}
