package MesClasses;

public class HelloWord {
int k; //variable de port�e classe sont des attributs de classe
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0; //port�e m�thode
       while (i<5)
       {
    	   int s; //port�e bloc
    	   System.out.println("helo Word++");
    	   i++;
    	   s=20;
       }//fin bloc
   
	}//fin main

	///methode 2
	public  int somme (int a, int b)
	{
		k=a+b;
		return k;
	}
}
