package MesClasses;

public enum EnumSexe {
M, F;
}
