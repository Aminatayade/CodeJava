package MesClasses;

public class SoldeException extends Exception {

	public SoldeException() {
		// TODO Auto-generated constructor stub
	}

	public SoldeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SoldeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SoldeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SoldeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
