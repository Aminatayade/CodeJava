package MesClasses;

public enum EnumJour {
LUNDI,MARDI,MERCREDI,JEUDI,VENDREDI,SAMEDI,DIMANCHE;	
}
